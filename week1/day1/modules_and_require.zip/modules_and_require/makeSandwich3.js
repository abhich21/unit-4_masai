const name = "Dhaval";

module.exports = () => {
  console.log(`${name} is making sandwich 3`);
};
