const makeSandwich1 = require("./makeSandWich1");
const makeSandwich2 = require("./makeSandWich2");
const makeSandwich3 = require("./makeSandWich3");

// makeSandwich1.makeSandwich1();
makeSandwich1.makePizza1();
makeSandwich2.makeSandwich2();
makeSandwich3();

makeSandwich1.makeSandwich1();

// require("./makeSandWich1")();
